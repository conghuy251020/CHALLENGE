import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import AlbumList from "./pages/AlbumList";
import AlbumDetail from "./pages/AlbumDetail";
import UserList from "./pages/UserList";
import UserDetail from "./pages/UserDetail";

function App() {
  return (
    <Router>
      <div className="container" style={{ padding: "20px" }}>
        <Routes>
          {" "}
          {/* Redirect mặc định */}{" "}
          <Route path="/" element={<Navigate to="/albums" />} /> {/* Album */}{" "}
          <Route path="/albums" element={<AlbumList />} />{" "}
          <Route path="/albums/:id" element={<AlbumDetail />} /> {/* User */}{" "}
          <Route path="/users" element={<UserList />} />{" "}
          <Route path="/users/:id" element={<UserDetail />} />{" "}
          {/* 404 fallback */}{" "}
          <Route path="*" element={<h2> Không tìm thấy trang </h2>} />
        </Routes>{" "}
      </div>{" "}
    </Router>
  );
}

export default App;
