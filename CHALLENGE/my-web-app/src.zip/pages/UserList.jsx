import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Avatar from "../components/Avatar";
import Loader from "../components/Loader";
import "../style/UserList.css";

export default function UserList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchUsers() {
      const res = await fetch("https://jsonplaceholder.typicode.com/users");
      const data = await res.json();
      setUsers(data);
      setLoading(false);
    }
    fetchUsers();
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="frame_list">
      <h1> Users </h1>{" "}
      <div className="album_list_2">
        <table width="100%" border="1" cellPadding="10">
          <thead>
            <tr>
              <th> ID </th> <th> Avatar </th> <th> Name </th> <th> Email </th>{" "}
              <th> Phone </th> <th> Website </th> <th> Actions </th>{" "}
            </tr>{" "}
          </thead>{" "}
          <tbody>
            {" "}
            {users.map((user) => (
              <tr key={user.id} className="tr-hover-2">
                <td> {user.id} </td>{" "}
                <td>
                  <Avatar name={user.name} size={40} />{" "}
                </td>{" "}
                <td> {user.name} </td>{" "}
                <td>
                  <a href={`mailto:${user.email}`}> {user.email} </a>{" "}
                </td>{" "}
                <td>
                  <a href={`tel:${user.phone}`}> {user.phone} </a>{" "}
                </td>{" "}
                <td>
                  <a
                    href={`https://${user.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {user.website}{" "}
                  </a>{" "}
                </td>{" "}
                <td>
                  <button onClick={() => navigate(`/users/${user.id}`)}>
                    <i className="fa-solid fa-eye" style={{ color: "#fcfcfc" }}>
                      {" "}
                    </i>{" "}
                    Show{" "}
                  </button>{" "}
                </td>{" "}
              </tr>
            ))}{" "}
          </tbody>{" "}
        </table>{" "}
      </div>{" "}
    </div>
  );
}
