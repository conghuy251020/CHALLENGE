import { useEffect, useState } from "react";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import Loader from "../components/Loader";
import Avatar from "../components/Avatar";
import Pagination from "../components/Pagination";

export default function AlbumList() {
  const [albums, setAlbums] = useState([]);
  const [users, setUsers] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [hoveredRow, setHoveredRow] = useState(null);

  const page = parseInt(searchParams.get("page")) || 1;
  const [itemsPerPage, setItemsPerPage] = useState(10);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      const [albumsRes, usersRes] = await Promise.all([
        fetch("https://jsonplaceholder.typicode.com/albums"),
        fetch("https://jsonplaceholder.typicode.com/users"),
      ]);
      const albumsData = await albumsRes.json();
      const usersData = await usersRes.json();
      const userMap = {};
      usersData.forEach((user) => (userMap[user.id] = user));
      setAlbums(albumsData);
      setUsers(userMap);
      setLoading(false);
    }
    fetchData();
  }, []);

  const paginatedAlbums = albums.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  const handleItemsPerPageChange = (e) => {
    const newValue = parseInt(e.target.value);
    setItemsPerPage(newValue);
    setSearchParams({ page: 1 });
  };

  return loading ? (
    <Loader />
  ) : (
    <div className="title_part">
      <h1> Albums </h1>{" "}
      <div className="album_list">
        <table border="1" cellPadding="10" width="100%">
          <thead>
            <tr>
              <th> ID </th> <th> Title </th> <th> User </th> <th> Actions </th>{" "}
            </tr>{" "}
          </thead>{" "}
          <tbody>
            {" "}
            {paginatedAlbums.map((album) => {
              const user = users[album.userId];
              return (
                <tr key={album.id} className="tr-hover">
                  <td> {album.id} </td> <td> {album.title} </td>{" "}
                  <td style={{ cursor: "pointer" }}>
                    <Link to={`/users/${user.id}`}>
                      <Avatar name={user.name} size={30} /> {user.name}{" "}
                    </Link>{" "}
                  </td>{" "}
                  <td>
                    <button onClick={() => navigate(`/albums/${album.id}`)}>
                      <i
                        className="fa-solid fa-eye"
                        style={{ color: "#fcfcfc" }}
                      ></i>{" "}
                      Show{" "}
                    </button>{" "}
                  </td>{" "}
                </tr>
              );
            })}{" "}
          </tbody>{" "}
        </table>{" "}
      </div>{" "}
      {/* Phân trang + chọn số lượng */}{" "}
      <div
        style={{
          gap: "20px",
          marginTop: "20px",
          display: "flex",
          justifyContent: "end",
          alignItems: "center",
        }}
      >
        <Pagination
          currentPage={page}
          totalPages={Math.ceil(albums.length / itemsPerPage)}
          baseUrl="/albums"
        />{" "}
        {/* Dropdown chọn số lượng */}{" "}
        <div class="page_display">
          <select
            id="itemsPerPage"
            value={itemsPerPage}
            onChange={handleItemsPerPageChange}
          >
            {[10, 20, 50, 100].map((value) => (
              <option key={value} value={value}>
                --{value}/ page --{" "}
              </option>
            ))}{" "}
          </select>{" "}
        </div>{" "}
      </div>{" "}
    </div>
  );
}
