import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Avatar from "../components/Avatar";
import Loader from "../components/Loader";
import "../style/AlbumList.css";
import "../style/UserDetail.css";

export default function UserDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [albums, setAlbums] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchUserData() {
      setLoading(true);
      const [userRes, albumsRes] = await Promise.all([
        fetch(`https://jsonplaceholder.typicode.com/users/${id}`),
        fetch(`https://jsonplaceholder.typicode.com/albums?userId=${id}`),
      ]);
      const userData = await userRes.json();
      const albumsData = await albumsRes.json();
      setUser(userData);
      setAlbums(albumsData);
      setLoading(false);
    }

    fetchUserData();
  }, [id]);

  if (loading) return <Loader />;
  if (!user) return <p> Không tìm thấy người dùng. </p>;

  return (
    <div className="page_link">
      <div
        className="return_link"
        onClick={() => navigate("/users")}
        style={{ cursor: "pointer" }}
      >
        <i className="fa-solid fa-rotate-left"> </i> <h3> Show Users </h3>{" "}
      </div>{" "}
      <div class="frame_large">
        <div className="frame_user">
          <div className="infor_user">
            <Avatar name={user.name} size={60} />{" "}
            <div className="email_name">
              <h2> {user.name} </h2>{" "}
              <p style={{ margin: 0 }}>
                {" "}
                <a href={`mailto:${user.email}`}> {user.email} </a>{" "}
              </p>{" "}
            </div>{" "}
          </div>{" "}
          <div className="title_part_1">
            <h1> Albums </h1>{" "}
          </div>{" "}
          <div className="album_list_1">
            <table border="1" cellPadding="10" width="100%">
              <thead>
                <tr>
                  <th> ID </th> <th> Title </th> <th> Actions </th>{" "}
                </tr>{" "}
              </thead>{" "}
              <tbody>
                {" "}
                {albums.map((album) => (
                  <tr
                    key={album.id}
                    className="tr-hover-1"
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.backgroundColor = "#f0f0f0")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.backgroundColor = "")
                    }
                  >
                    <td> {album.id} </td> <td> {album.title} </td>{" "}
                    <td>
                      <button onClick={() => navigate(`/albums/${album.id}`)}>
                        <i
                          className="fa-solid fa-eye"
                          style={{ color: "#fcfcfc" }}
                        ></i>{" "}
                        Show{" "}
                      </button>{" "}
                    </td>{" "}
                  </tr>
                ))}{" "}
              </tbody>{" "}
            </table>{" "}
          </div>{" "}
        </div>{" "}
      </div>{" "}
    </div>
  );
}
