import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Avatar from "../components/Avatar";
import Loader from "../components/Loader";
import "../style/AlbumDetail.css";

export default function AlbumDetail() {
  const { id } = useParams();
  const [album, setAlbum] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAlbumDetail() {
      setLoading(true);
      const albumRes = await fetch(
        `https://jsonplaceholder.typicode.com/albums/${id}`
      );
      const albumData = await albumRes.json();
      setAlbum(albumData);

      const [userRes, photosRes] = await Promise.all([
        fetch(`https://jsonplaceholder.typicode.com/users/${albumData.userId}`),
        fetch(`https://jsonplaceholder.typicode.com/photos?albumId=${id}`),
      ]);

      const userData = await userRes.json();
      const photoData = await photosRes.json();

      setUser(userData);
      setPhotos(photoData);
      setLoading(false);
    }

    fetchAlbumDetail();
  }, [id]);

  if (loading) return <Loader />;
  if (!album || !user) return <p> Không tìm thấy thông tin. </p>;

  return (
    <div className="album-container">
      <div className="album-header">
        <Avatar name={user.name} size={50} />{" "}
        <div className="user-info">
          <Link to={`/users/${user.id}`} className="user-name">
            {" "}
            {user.name}{" "}
          </Link>{" "}
          <p>
            {" "}
            <a href={`mailto:${user.email}`}> {user.email} </a>{" "}
          </p>{" "}
        </div>{" "}
      </div>{" "}
      <h2 className="album-title"> {album.title} </h2>{" "}
      <div className="photo-grid">
        {" "}
        {photos.map((photo) => (
          <a
            key={photo.id}
            href={photo.url}
            target="_blank"
            rel="noopener noreferrer"
            className="photo-item"
          >
            <img src={photo.thumbnailUrl} alt={photo.title} />{" "}
            <p> {photo.title} </p>{" "}
          </a>
        ))}{" "}
      </div>{" "}
    </div>
  );
}
