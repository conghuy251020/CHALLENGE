export default function Loader() {
  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <div className="spinner" style={spinnerStyle}>
        {" "}
      </div>{" "}
      <p> Đang tải dữ liệu... </p>{" "}
    </div>
  );
}

const spinnerStyle = {
  width: "40px",
  height: "40px",
  border: "5px solid #ccc",
  borderTop: "5px solid #3498db",
  borderRadius: "50%",
  animation: "spin 1s linear infinite",
  margin: "0 auto",
};

// Add keyframes for animation in global CSS
// @keyframes spin {
//   0% { transform: rotate(0deg); }
//   100% { transform: rotate(360deg); }
// }
