export default function Avatar({ name, size = 40 }) {
  const url = `https://ui-avatars.com/api/?name=${encodeURIComponent(
    name
  )}&size=${size}&background=random`;

  return (
    <img
      src={url}
      alt={`Avatar of ${name}`}
      width={size}
      height={size}
      style={{ borderRadius: "50%" }}
    />
  );
}
