import { Link } from "react-router-dom";
import "../style/AlbumList.css";

export default function Pagination({ currentPage, totalPages, baseUrl }) {
  const createPages = () => {
    const pages = [];
    const delta = 1;

    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 2 + delta) pages.push("...");

      const start = Math.max(2, currentPage - delta);
      const end = Math.min(totalPages - 1, currentPage + delta);
      for (let i = start; i <= end; i++) pages.push(i);

      if (currentPage < totalPages - delta - 1) pages.push("...");
      pages.push(totalPages);
    }

    return pages;
  };

  const pages = createPages();

  return (
    <div className="pagination-container">
      {" "}
      {currentPage > 1 && (
        <Link to={`${baseUrl}?page=${currentPage - 1}`} className="page-link">
          {" "}
          {"<"}{" "}
        </Link>
      )}{" "}
      {pages.map((p, i) =>
        p === "..." ? (
          <span key={i} className="page-ellipsis">
            ...{" "}
          </span>
        ) : (
          <Link
            key={i}
            to={`${baseUrl}?page=${p}`}
            className={`page-link ${p === currentPage ? "active" : ""}`}
          >
            {p}{" "}
          </Link>
        )
      )}{" "}
      {currentPage < totalPages && (
        <Link to={`${baseUrl}?page=${currentPage + 1}`} className="page-link">
          {" "}
          {">"}{" "}
        </Link>
      )}{" "}
    </div>
  );
}
